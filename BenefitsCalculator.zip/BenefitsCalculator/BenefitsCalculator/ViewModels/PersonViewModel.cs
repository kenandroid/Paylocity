﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BenefitsCalculator.ViewModels
{
    public class PersonViewModel
    {
        public PersonViewModel(String firstName, String lastName)
        {
            Name = firstName + " " + lastName;
        }

        public String Name { get; set; }
    }
}
