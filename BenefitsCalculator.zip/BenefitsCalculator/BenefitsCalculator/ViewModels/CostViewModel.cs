﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BenefitsCalculator.ViewModels
{
    public class CostViewModel
    {
        private double employeeSalary;

        public CostViewModel()
        {

        }

        public CostViewModel(double employeeSalary)
        {
            this.employeeSalary = employeeSalary;
        }

        public void ChangeTotalCost(double newCost, double deduction)
        {
            totalCost += (newCost - deduction);
            costPerPay = Math.Round(totalCost / 26, 2);
            netPerPay = employeeSalary - costPerPay;
        }

        public double totalCost { get; set; }
        public double costPerPay { get; set; }
        public double netPerPay { get; set; }

    }
}
