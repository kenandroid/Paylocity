﻿using BenefitsCalculator.Models;
using BenefitsServices;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BenefitsCalculator.ViewModels
{
    public class FamilyBenefitAnalysisViewModel
    {
        public List<Tuple<PersonViewModel, BenefitAnalysisViewModel>> famliyAnalysis;
        public CostViewModel costView { get; set; }
    }
}
