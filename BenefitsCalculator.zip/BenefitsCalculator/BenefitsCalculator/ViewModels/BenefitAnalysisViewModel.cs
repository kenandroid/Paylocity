﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BenefitsCalculator.ViewModels
{
    public class BenefitAnalysisViewModel
    {
        public String Description { get; set; }
        public double Cost { get; set; }
        public double Deduction { get; set; }
    }
}
