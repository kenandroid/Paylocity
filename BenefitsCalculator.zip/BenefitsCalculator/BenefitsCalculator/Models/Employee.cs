﻿using BenefitsServices;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace BenefitsCalculator.Models
{
    public class Employee : Person
    {

        public List<Dependent> dependents { get; set; }
        [Required]
        public double salary { get; set; }
    }
}
