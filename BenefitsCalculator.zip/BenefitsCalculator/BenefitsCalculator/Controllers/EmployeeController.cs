﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Encodings.Web;
using System.Threading.Tasks;
using BenefitsServices;
using Microsoft.AspNetCore.Mvc;
using BenefitsCalculator.Data;
using BenefitsCalculator.Models;
using BenefitsCalculator.ViewModels;

namespace BenefitsCalculator.ControllersBase
{
    public class EmployeeController : Controller
    {
        private IEmployeeRepository repository;

        public IActionResult Index()
        {
            return View();
        }

        private BenefitAnalysisViewModel buildAnalysisSummary(Person person, double baseCost)
        {
            var analysisView = new BenefitAnalysisViewModel();
            var personanalysis = getBenefitAnalysis(person);

            foreach (var item in personanalysis)
            {
                if (item == null) continue;
                analysisView.Description += item.Description;
                analysisView.Deduction += item.Deductions;
            }
            analysisView.Cost = baseCost;

            return analysisView;
        }

        public IActionResult ViewAnalysis(int Id)
        {
            FamilyBenefitAnalysisViewModel familyBenefitAnalysisViewModel = new FamilyBenefitAnalysisViewModel();
            Employee employee = GetFamily(Id);

            CostViewModel costViewModel = new CostViewModel(employee.salary);
            PersonViewModel personView = new PersonViewModel(employee.FirstName, employee.LastName);
            Tuple<PersonViewModel, BenefitAnalysisViewModel> analysis = new Tuple<PersonViewModel, BenefitAnalysisViewModel>(personView, buildAnalysisSummary(employee, 1000));

            familyBenefitAnalysisViewModel.famliyAnalysis = new List<Tuple<PersonViewModel, BenefitAnalysisViewModel>>();
            familyBenefitAnalysisViewModel.famliyAnalysis.Add(analysis);
            //costViewModel.totalCost += analysis.Item2.Cost - analysis.Item2.Deduction;
            costViewModel.ChangeTotalCost(analysis.Item2.Cost, analysis.Item2.Deduction);

            if (employee.dependents != null)
                foreach (Dependent dependent in employee.dependents)
                {
                    personView = new PersonViewModel(dependent.FirstName, dependent.LastName);
                    analysis = new Tuple<PersonViewModel, BenefitAnalysisViewModel>(personView, buildAnalysisSummary(dependent, 500));
                    familyBenefitAnalysisViewModel.famliyAnalysis.Add(analysis);
                    //costViewModel.totalCost += analysis.Item2.Cost - analysis.Item2.Deduction;
                    costViewModel.ChangeTotalCost(analysis.Item2.Cost, analysis.Item2.Deduction);
                }

            //costViewModel.costPerPay = Math.Round(costViewModel.totalCost / 26, 2);
            //costViewModel.netPerPay = employee.salary - costViewModel.costPerPay;

            familyBenefitAnalysisViewModel.costView = costViewModel;

            return View(familyBenefitAnalysisViewModel);
        }

        public EmployeeController(IEmployeeRepository repository)
        {
            this.repository = repository;
        }

        private Employee GetFamily(int Id)
        {
            var employee = repository.GetFamily(Id);

            return employee;
        }

        public ActionResult<Employee> Add(int Id, String personType, String firstName, String lastName)
        {
            Employee employee = new Employee();

            if (personType.ToUpper().Equals("EMPLOYEE"))
            {
                employee = addEmployee(firstName, lastName);
                repository.SaveEmployee(employee);
            }
            else
            {
                employee = GetFamily(Id);
                if (employee.dependents == null) employee.dependents = new List<Dependent>();
                employee.dependents.Add(addDependent(firstName, lastName));
                repository.SaveDependent(employee);
            }

            ViewBag.Id = employee.Id;
            return View("Index");
        }

        private Dependent addDependent(string firstName, string lastName)
        {
            Dependent dependent = new Dependent();

            dependent.FirstName = firstName;
            dependent.LastName = lastName;

            return dependent;
        }

        private Employee addEmployee(string firstName, string lastName)
        {
            var employee = new Employee();
            employee.FirstName = firstName;
            employee.LastName = lastName;

            return employee;
        }

        private List<BenefitAnalysis> getBenefitAnalysis(Person covered)
        {
            IndividualHealthConditions individualHealthConditions = new IndividualHealthConditions();

            individualHealthConditions.FirstName = covered.FirstName;
            individualHealthConditions.LastName = covered.LastName;
            CostCalculator costCalculator = new CostCalculator();

            return costCalculator.Analyze(individualHealthConditions);
        }
    }
}
