﻿using BenefitsCalculator.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BenefitsCalculator.Data
{
    public class SqlEmployeeRepository : IEmployeeRepository
    {
        private BenefitsContext benefitsContext;

        public SqlEmployeeRepository(BenefitsContext benefitsContext)
        {
            this.benefitsContext = benefitsContext;
        }
        public List<Employee> GetAllEmployees()
        {
            return benefitsContext.Employees.ToList();
        }

        public Employee GetEmployee(int id)
        {
            throw new NotImplementedException();
        }

        public Employee GetFamily(int Id)
        {
            Employee employee = benefitsContext.Employees.Where(s => s.Id == Id).Include(s => s.dependents).FirstOrDefault();

            //Obviously not the best way but its constant for just this example.  This should be in a Db.
            employee.salary = 2000;
            return employee;
        }

        public void SaveEmployee(Employee employee)
        {
            benefitsContext.Employees.Add(employee);

            benefitsContext.SaveChanges();
        }

        public void SaveDependent(Employee employee)
        {
            benefitsContext.Employees.Update(employee);

            benefitsContext.SaveChanges();
        }
    }
}
