﻿using BenefitsCalculator.Models;
using Microsoft.EntityFrameworkCore;

namespace BenefitsCalculator.Data
{
    public class BenefitsContext : DbContext
    {
        public BenefitsContext(DbContextOptions<BenefitsContext> context) : base(context)
        {

        }

        public DbSet<Employee> Employees { get; set; }
        public DbSet<Dependent> Dependents { get; set; }
    }
}
