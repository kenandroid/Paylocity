﻿using BenefitsCalculator.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace BenefitsCalculator.Data
{
    public interface IEmployeeRepository
    {
        Employee GetFamily(int Id);
        void SaveEmployee(Employee employee);
        void SaveDependent(Employee employee);
    }
}