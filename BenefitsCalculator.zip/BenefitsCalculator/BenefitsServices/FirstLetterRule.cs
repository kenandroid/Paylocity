﻿namespace BenefitsServices
{
    internal class FirstLetterRule : IBenefitRule
    {
        public BenefitAnalysis analyze(IndividualHealthConditions individualHealthConditions)
        {
            var benefitAnalysis = new BenefitAnalysis(0, "");

            if (individualHealthConditions.FirstName.StartsWith("A", false, null)
                || individualHealthConditions.LastName.StartsWith("A", false, null))
            {
                benefitAnalysis.Description = "Name starts with the lucky letter.";
                benefitAnalysis.Deductions = .1 * 500;
            }

            return benefitAnalysis;
        }
    }
}