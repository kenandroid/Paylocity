﻿using System;
using System.Collections.Generic;

namespace BenefitsServices
{
    public class CostCalculator : ICostCalculator
    {
        private List<IBenefitRule> rulesEngines;
        public CostCalculator()
        {
            //I actually see these rules living in a Db
            //Each rule would have its own column so multiple variations of the rule could exist.
            //Each rule would also have a column for if its active, a value to use in the rule and an amount under either addition or deduction.
            //Addition would be if some item like smoking or weight adds extra to your base cost.
            //A factory class would look at the Db and create active rules and load them instead of the lines below.
            rulesEngines = new List<IBenefitRule>();
            rulesEngines.Add(new FirstLetterRule());
        }

        public List<BenefitAnalysis> Analyze(IndividualHealthConditions individualHealthConditions)
        {
            List<BenefitAnalysis> analyses = new List<BenefitAnalysis>();

            foreach (IBenefitRule rule in rulesEngines)
            {
                analyses.Add(rule.analyze(individualHealthConditions));             
            }

            return analyses;
        }
    }
}
