﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BenefitsServices
{
    public interface ICostCalculator
    {
        public List<BenefitAnalysis> Analyze(IndividualHealthConditions individualHealthConditions);
    }
}
