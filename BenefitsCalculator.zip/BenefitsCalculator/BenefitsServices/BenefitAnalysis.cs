﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BenefitsServices
{
    public class BenefitAnalysis
    {
        public BenefitAnalysis()
        {

        }

        public BenefitAnalysis(double deduction, String description)
        {
            this.Deductions = deduction;
            this.Description = description;
        }
        
        [Key]
        public int Id { get; set; }
        public String Description { get; set; }
        public Double BaseCost { get; set; }
        public Double Deductions { get; set; }
    }
}
