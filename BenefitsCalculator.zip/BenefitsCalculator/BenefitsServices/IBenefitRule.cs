﻿namespace BenefitsServices
{
    internal interface IBenefitRule
    {
        BenefitAnalysis analyze(IndividualHealthConditions individualHealthConditions);
    }
}